# Author: Muskan Arora
# Date: 1 January 2021
from django.contrib.auth import authenticate, login, logout
from django.utils.decorators import method_decorator
from django.http import HttpResponse,HttpResponseRedirect
from django.template.response import TemplateResponse
import os
import requests
import bleach
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .views import *
from .form import createform

class class_authenticate():
    def loginuser(self,request):
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request,username=username,password=password)
            if user:
                login(request,user)
                return HttpResponseRedirect('/')
            else:
                messages.info(request, 'Credentials are Incorrect')
                return TemplateResponse(request, 'login.html')
        else:
             return TemplateResponse(request,'login.html')
    
    def logoutuser(self,request):
        logout(request)
        messages.success(request,'Signed Out')
        return HttpResponseRedirect('login')
    

@method_decorator (login_required, name = 'home')
class class_main():
    def home(self,requests):
        return TemplateResponse(requests,'index.html')

def main():
    object_main = class_main()
    return object_main

def authentication():
    object_authenticate = class_authenticate()
    return object_authenticate
"""
ASGI config for Text_Summarizer project.

It exposes the ASGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/3.1/howto/deployment/asgi/

"""
# Author: Muskan Arora
# Date: 1 January 2021

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Text_Summarizer.settings')

application = get_asgi_application()

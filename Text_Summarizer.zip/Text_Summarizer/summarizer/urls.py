from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

object_views = views.main()
urlpatterns = [

path('process/',object_views.process,name='process'),
path('download',object_views.download,name='download'),

] + static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
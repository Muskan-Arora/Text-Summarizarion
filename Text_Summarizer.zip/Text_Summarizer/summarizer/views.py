# Author: Muskan Arora
# Date: 1 January 2021
from django.contrib.auth import authenticate, login, logout
from django.utils.decorators import method_decorator
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.template.response import TemplateResponse
import os
import requests
import uuid,json
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from . import model

@method_decorator(login_required,name = 'process')
@method_decorator(login_required,name = 'download')

class class_process():
    
    def __init__(self):
        self.object_model = model.main_frequency()
        self.input_value=[]
        self.output_download = ''
    
    def process(self,request):
        if request.method=="POST":
            file = request.FILES.get('text_file')
            model_value = request.POST.get('model_name')
            if file.name.endswith('.txt'):
                if model_value == "Spacy-Frequency":
                    self.input_value,output= self.object_model.text_summarizer(file)
                    self.output_download = ' '.join(output)
                elif model_value == "TextRank":
                    self.input_value,output = self.object_model.textrank_summarizer(file)
                    self.output_download = ' '.join(output)
                else:
                    self.input_value,output= self.object_model.Cosine_Similarity_Summary(file)
                    self.output_download = ' '.join(output)
                return TemplateResponse(request,"index_results.html",{'input_html':self.input_value,'output_html':output})
            else:
                error = "Please upload valid file"
                return TemplateResponse(request,"index.html", context = {'exception':error})
                
    def download(self,request):
        response = HttpResponse(self.output_download,content_type='text/plain')
        response['Content-Disposition'] = 'attachment;filename= Summary_Prediction.txt'
        return response

def main():
    object_process = class_process()
    return object_process
        
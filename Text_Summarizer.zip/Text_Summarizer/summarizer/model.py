# Author: Muskan Arora
# Date: 1 January 2021

import numpy as np
import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
from heapq import nlargest
import os
import pandas as pd
import nltk
nltk.download('punkt')
import re
from nltk.tokenize import sent_tokenize
nltk.download('stopwords')
from nltk.corpus import stopwords
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx
from nltk.cluster.util import cosine_distance
stop_words = stopwords.words('english')



class frequency_class:
    
    def __init__(self):
        self.nlp = spacy.load('en_core_web_lg')
        
    def file_name(self,file):
        filename = os.path.splitext(file)[0]
        return file_name
    
    def stopwords_removal(self,sent): 
        stop_words = stopwords.words('english')
        sent_stop_removed = " ".join([i for i in sent if i not in stop_words])
        return sent_stop_removed
    
    
    def text_summarizer(self,file):
        if file.name.endswith('txt'):
           
            content = file.readlines()
            text_content = []
            for i in content:
                i = i.decode(encoding='cp1252')
                text_content.append(i.replace('\n',''))
            original_document = ' '.join(text_content)
            
            original_document = self.convert_lemma(original_document)
            
            
            docx=self.nlp(original_document)
            stopwords=list(STOP_WORDS) #list of stop words
            word_freq ={}
            for word in docx: # calculating frequency of the words
                if word.text not in stopwords:
                    if word.text not in word_freq.keys():
                        word_freq[word.text]=1
                    else:
                        word_freq[word.text]+=1
            
            max_freq=max(word_freq.values()) #calculating maximum word frequency        
            
            for word in word_freq.keys(): # normalizing by dividing each frequency by maximum frequency
                word_freq[word]=(word_freq[word]/max_freq)
            
            sentence_list=[sentence for sentence in docx.sents]    # creating a list of sentences
            
            sentence_scores={} #calculating sentence scores based on some conditions 
            for sent in sentence_list:
                for word in sent:
                    if word.text.lower() in word_freq.keys():
                        if len(sent.text.split(" "))<30:
                            if sent not in sentence_scores.keys():
                                sentence_scores[sent]=word_freq[word.text.lower()]
                            else:
                                sentence_scores[sent]+=word_freq[word.text.lower()]
                                
            summary_sentences=nlargest(6,sentence_scores,key=sentence_scores.get) #calculating the largest sentence based on sentence scores
            final_sentences=[w.text for  w in summary_sentences]
            summarized_document=" ".join(final_sentences)
            
            return text_content,[summarized_document]
        else:
            value = 'error'
            return value
    
    def remove_stopwords(self,text):
        sent = []
        for word in text:
            lexeme = self.nlp.vocab[word]
            if lexeme.is_stop ==False:
                sent.append(word)
        return sent
    
    def convert_lemma(self,text):
        text = self.nlp(text)
        lemma_text = ' '.join([token.lemma_ for token in text if token.lemma_ !='-PRON-'])
        return lemma_text
    
    def textrank_summarizer(self,file):
        if file.name.endswith('txt'):
            content = file.readlines()
            sentences = []
            for i in content:
                i = i.decode(encoding='cp1252')
                sentences.append(i.replace('\n',''))
            # glove vectors for words
            word_embedings = {}
            glove_file = open(r"./summarizer/glove_vectors/glove.6B.100d.txt", encoding='utf-8')
            for i in glove_file:
                values = i.split()
                word = values[0]
                coeficients = np.asarray(values[1:], dtype='float32')
                word_embedings[word] = coeficients
            glove_file.close()
            print("okk")
            # text cleaning
            # punctuation remove
            cleaned_sentences = pd.Series(sentences).str.replace("[^a-zA-Z]", " ")
        
            # lower case 
            cleaned_sentences = [s.lower() for s in cleaned_sentences]
            
            # stopwords removal
            cleaned_sentences = [stopwords_removal(r.split()) for r in cleaned_sentences]
            
            # glove vectors for sentences using word vectors
            print("test")
            sentence_vectors = []
            for i in cleaned_sentences:
                if len(i) != 0:
                    v = sum([word_embedings.get(w, np.zeros((100,))) for w in i.split()])/(len(i.split())+0.001)
                else:
                    v = np.zeros((100,))
                sentence_vectors.append(v)
            #similarity matrix 
            similarity_matrix = np.zeros([len(sentences), len(sentences)])
            
            for p in range(len(sentences)):
                for q in range(len(sentences)):
                    if p != q:
                        similarity_matrix[p][q] = cosine_similarity(sentence_vectors[p].reshape(1,100), sentence_vectors[q].reshape(1,100))[0,0]
            
            # using networkx for unique values
            matrix_networks_graph = nx.from_numpy_array(similarity_matrix)
            similarity_scoring = nx.pagerank(matrix_networks_graph)
            
            # text ranking
            textrank_sent = sorted(((similarity_scoring[i],s) for i,s in enumerate(sentences)), reverse=True)
            
            print("here")
            
            output = []
            for z in range(1):
                output.append(textrank_sent[z][1])
    
            return sentences,output
        else:
                
            value = 'error'
            return value
    
    def sentence_similarity(self,sentence_1, sentence_2):
        sentence_1 = [i.lower() for i in sentence_1]  #changing the sentence1 into lower case
        sentence_2 = [i.lower() for i in sentence_2]  #changing the sentence2 into lower case
        stopwords = stop_words
        words = list(set(sentence_1 + sentence_2))
     
        vector_1 = [0] * len(words)
        vector_2 = [0] * len(words)
     
        # build the vector for the first sentence
        for i in sentence_1:
            if i in stopwords:
                continue
            vector_1[words.index(i)] += 1
     
        # build the vector for the second sentence
        for i in sentence_2:
            if i in stopwords:
                continue
            vector_2[words.index(i)] += 1
    
        value = 1 - cosine_distance(vector_1, vector_2)
        return value  #cosine distance between 2 vectors 
    
    def create_similarity_matrix(self,sentences):
        # Create an empty similarity matrix
        similarity_matrix = np.zeros((len(sentences), len(sentences)))
     
        for x1 in range(len(sentences)):
            for x2 in range(len(sentences)):
                if x1 == x2: #ignore if both are same sentences
                    continue 
                similarity_matrix[x1][x2] = self.sentence_similarity(sentences[x1], sentences[x2]) #calling the sentence similarity function
    
        return similarity_matrix

    
    def Cosine_Similarity_Summary(self,file):
        if file.name.endswith('txt'):
            
            content = file.readlines()
            sentences = []
            for i in content:
                i = i.decode(encoding='cp1252')
                sentences.append(i.replace('\n',''))
        summary = []
        # 1 - Generate Similarity Martix for sentences
        sentence_similarity_martix = self.create_similarity_matrix(sentences)
        # 2 - Rank sentences in similarity martix
        similarity_graph = nx.from_numpy_array(sentence_similarity_martix)
        scores = nx.pagerank(similarity_graph)
        # 3 - sorting the rank and select top n sentences
        sentence_ranked = sorted(((scores[i],s) for i,s in enumerate(sentences)), reverse=True)    
        for i in range(5):
            summary.append(sentence_ranked[i][1])
        return sentences,summary

    
def main_frequency():
    object_main = frequency_class()
    return object_main
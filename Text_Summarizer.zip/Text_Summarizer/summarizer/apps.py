from django.apps import AppConfig


class SummarizerConfig(AppConfig):
    name = 'summarizer'
